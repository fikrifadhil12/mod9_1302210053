// var nama = prompt("Masukan Nama Kamu");

// var nim = prompt("Masukan NIM Kamu");

// alert(" Nama " + nama);
// alert(" Nim" + nim);
